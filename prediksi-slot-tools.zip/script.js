
const hasil = [
  "💥 MEGA WIN! Modal kecil, hasil gila!",
  "🔔 JACKPOT SEBENTAR LAGI!",
  "💸 Waktu terbaik: main jam 02:00 - 03:00 WIB",
  "🔥 Buyspin sekarang, scatter udah dekat!",
  "😴 Santai dulu, slot lagi dingin...",
  "🚀 JP di depan mata, gas terus!",
  "🔄 Ganti game dulu, feeling kurang pas",
  "⚠️ Hati-hati! Mode sedot aktif!",
  "🍀 Hari hoki! Modal 10rb bisa jadi 1jt!",
  "⏳ Tunggu 30 menit, lalu all in!"
];

function prediksi() {
  const resultText = document.getElementById("result");
  resultText.innerText = "⏳ Menganalisa algoritma slot...";

  setTimeout(() => {
    const randomIndex = Math.floor(Math.random() * hasil.length);
    resultText.innerText = hasil[randomIndex];
  }, 1500);
}
